﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AuthorizeButton_Click(object sender, RoutedEventArgs e)
        {
            if (EmployeeCodeTextBox.Text.Length > 0)
            {
                ApplicationsListView.ItemsSource = Data.Applications.Where(app => app.EmployeeCode == EmployeeCodeTextBox.Text);
            }
            else
            {
                MessageBox.Show("Пожалуйста, введите код сотрудника.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void VerifyApplicationButton_Click(object sender, RoutedEventArgs e)
        {
            if (ApplicationsListView.SelectedItem != null)
            {
                var selectedApplication = (Data.Application)ApplicationsListView.SelectedItem;

                VerificationWindow.ShowDialog();

                if (selectedApplication.VerificationStatus == "Одобрено")
                {
                    MessageBox.Show("Заявка одобрена.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else if (selectedApplication.VerificationStatus == "Отклонено")
                {
                    MessageBox.Show("Заявка отклонена.", "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите заявку.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ApproveButton_Click(object sender, RoutedEventArgs e)
        {
            if (ApplicationsListView.SelectedItem != null)
            {
                var selectedApplication = (Data.Application)ApplicationsListView.SelectedItem;
                selectedApplication.VerificationStatus = "Одобрено";

                VisitDateTimeTextBox.Text = selectedApplication.VisitDateTime.ToString();
                EditingModificationTextBox.Text = selectedApplication.EditingModification;

                VerificationWindow.Close();
            }
        }

        private void RejectButton_Click(object sender, RoutedEventArgs e)
        {
            if (ApplicationsListView.SelectedItem != null)
            {
                var selectedApplication = (Data.Application)ApplicationsListView.SelectedItem;
                selectedApplication.VerificationStatus = "Отклонено";

                RejectionReasonTextBox.Text = selectedApplication.RejectionReason;

                VerificationWindow.Close();
            }
        }
        public static class Data
        {
            public struct Application
            {
                public string EmployeeCode;
                public DateTime VisitDateTime;
                public string EditingModification;
                public string VerificationStatus;
                public string RejectionReason;
            }

            public static List<Application> Applications = new List<Application>
    {
        new Application
        {
            EmployeeCode = "001",
            VisitDateTime = new DateTime(2021, 12, 24, 14, 30, 0),
            EditingModification = "Общий осмотр.",
            VerificationStatus = "Одобрено",
            RejectionReason = ""
        },
        new Application
        {
            EmployeeCode = "002",
            VisitDateTime = new DateTime(2021, 12, 24, 15, 00, 0),
            EditingModification = "Корректировка порядка установки и отключения аппаратуры.",
            VerificationStatus = "Отклонено",
            RejectionReason = "Необходимо предварительное уведомление."
        }
    };
        }
    }
}