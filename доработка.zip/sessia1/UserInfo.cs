﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace sessia1
{
    public class UserInfo
    {
        public static String CustomerName = "";
        public static String CustomerEmail = "";
    }
}