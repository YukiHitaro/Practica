﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Data.SqlClient;
namespace sessia1
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        SqlConnection con;
        SqlCommand cmd;
        SqlDataReader reader;
        static String connectionString = @"Data Source=KAB17-06\SQLEXPRESS;Initial Catalog=Guardian-pro;Integrated Security=True";

        public Window1()
        {
            InitializeComponent();
        }
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            String message = "Неверные учетные данные"; try
            {
                con = new SqlConnection(connectionString); con.Open(); 
                cmd = new SqlCommand("SELECT * FROM Авторизация WHERE Email=@Email", con); 
                cmd.Parameters.AddWithValue("@Email", txtUserId.Text.ToString()); 
                reader = cmd.ExecuteReader(); if (reader.Read()) { if (reader["Пароль"].ToString().Equals(txtPassword.Password.ToString(), StringComparison.InvariantCulture)) 
                { message = "1"; UserInfo.CustomerEmail = txtUserId.Text.ToString(); UserInfo.CustomerName = reader["ID"].ToString(); } }

                reader.Close();
                reader.Dispose();
                cmd.Dispose();
                con.Close();

            }
            catch (Exception ex)
            {
                message = ex.Message.ToString();
            }
            if (message == "1")
            {
                MainWindow mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            else
                MessageBox.Show(message, "Info");
        }
        private void Register_Click(object sender, RoutedEventArgs e)
        {
            RegistrationWindow registrationWindow = new RegistrationWindow();
            registrationWindow.ShowDialog();
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}