﻿using System;
using System.Windows;

namespace sessia1
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            personalVisitButton.Click += PersonalVisitButton_Click;
            groupVisitButton.Click += GroupVisitButton_Click;
        }

        private void PersonalVisitButton_Click(object sender, RoutedEventArgs e)
        {
            Zapis_na_meropriyatie personalVisitForm = new Zapis_na_meropriyatie();
            personalVisitForm.ShowDialog();
        }

        private void GroupVisitButton_Click(object sender, RoutedEventArgs e)
        {
            Zapis_na_group_meropriyatie groupVisitForm = new Zapis_na_group_meropriyatie();
            groupVisitForm.ShowDialog();
        }
    }
}