﻿using System.Threading.Tasks;
using System.Windows;

namespace WpfApp
{
    public partial class VerificationWindow : Window
    {
        public VerificationWindow()
        {
            InitializeComponent();
        }

        private async void ApproveButton_Click(object sender, RoutedEventArgs e)
        {

            await ApproveAsync();
        }

        private async Task ApproveAsync()
        {

            Close();
        }

        private async void RejectButton_Click(object sender, RoutedEventArgs e)
        {
           await RejectAsync();
        }

        private async Task RejectAsync()
        {
            Close();
        }
    }
}