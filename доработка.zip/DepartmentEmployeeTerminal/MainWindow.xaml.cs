﻿using System.Threading.Tasks;
using System.Windows;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void AuthorizeButton_Click(object sender, RoutedEventArgs e)
        {
            // Simulate authorization
            await AuthorizeAsync();
        }

        private async Task AuthorizeAsync()
        {
            // Simulate authorization process
            // ...

            // Show the VerificationWindow after authorization
            await ShowVerificationWindowAsync();
        }

        private async Task ShowVerificationWindowAsync()
        {
            VerificationWindow verificationWindow = new VerificationWindow();
            verificationWindow.ShowDialog();
        }
    }
}