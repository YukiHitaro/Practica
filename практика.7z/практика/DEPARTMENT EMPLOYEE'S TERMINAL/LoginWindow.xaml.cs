﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace WpfApp
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string connectionString = @"Data Source=KAB17-06\SQLEXPRESS;Initial Catalog=Guardian-pro;Integrated Security=True";
            string query = "SELECT * FROM Сотрудники WHERE Код_сотрудника = @Code AND Пароль = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Code", txtCode.Text);
                command.Parameters.AddWithValue("@Password", pwbPassword.Password);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // If login is successful, close the login window and open the main window
                        this.Close();
                        var mainWindow = new MainWindow();
                        mainWindow.Show();
                    }
                    else
                    {
                        lblMessage.Content = "Invalid code or password.";
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error");
                }
            }
        }
    }
}