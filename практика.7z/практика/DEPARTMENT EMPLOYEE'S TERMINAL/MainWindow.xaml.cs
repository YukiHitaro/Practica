﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace WpfApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            // Load data from the database and populate UI elements
        }

    }
}