﻿
namespace sessia1
{
    partial class Zapis_na_group_meropriyatie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Zapis_na_group_meropriyatie));
            this.oformit_zayavky = new System.Windows.Forms.Button();
            this.clear = new System.Windows.Forms.Button();
            this.prikrepit_file = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.nomer = new System.Windows.Forms.TextBox();
            this.seriya = new System.Windows.Forms.TextBox();
            this.Data_rozhdeniya = new System.Windows.Forms.TextBox();
            this.Primechanie = new System.Windows.Forms.TextBox();
            this.organization = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.TextBox();
            this.Telefon = new System.Windows.Forms.TextBox();
            this.Otchestvo = new System.Windows.Forms.TextBox();
            this.Imya = new System.Windows.Forms.TextBox();
            this.Familiya = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.FIO = new System.Windows.Forms.TextBox();
            this.podrazdelenie = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.target_visit = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Spisok_posetitelei = new System.Windows.Forms.PictureBox();
            this.spisok = new System.Windows.Forms.Label();
            this.table = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spisok_posetitelei)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.table)).BeginInit();
            this.SuspendLayout();
            // 
            // oformit_zayavky
            // 
            this.oformit_zayavky.ForeColor = System.Drawing.SystemColors.ControlText;
            this.oformit_zayavky.Location = new System.Drawing.Point(650, 403);
            this.oformit_zayavky.Name = "oformit_zayavky";
            this.oformit_zayavky.Size = new System.Drawing.Size(121, 34);
            this.oformit_zayavky.TabIndex = 101;
            this.oformit_zayavky.Text = "Оформить заявку";
            this.oformit_zayavky.UseVisualStyleBackColor = true;
            this.oformit_zayavky.Click += new System.EventHandler(this.oformit_zayavky_Click);
            // 
            // clear
            // 
            this.clear.BackColor = System.Drawing.SystemColors.ControlLight;
            this.clear.Location = new System.Drawing.Point(526, 403);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(114, 34);
            this.clear.TabIndex = 100;
            this.clear.Text = "Очистить форму";
            this.clear.UseVisualStyleBackColor = false;
            this.clear.Click += new System.EventHandler(this.clear_Click);
            // 
            // prikrepit_file
            // 
            this.prikrepit_file.Location = new System.Drawing.Point(32, 416);
            this.prikrepit_file.Name = "prikrepit_file";
            this.prikrepit_file.Size = new System.Drawing.Size(179, 21);
            this.prikrepit_file.TabIndex = 99;
            this.prikrepit_file.Text = "Прикрепить файл";
            this.prikrepit_file.UseVisualStyleBackColor = true;
            this.prikrepit_file.Click += new System.EventHandler(this.prikrepit_file_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(84, 384);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(212, 16);
            this.label22.TabIndex = 97;
            this.label22.Text = "Прикрепляемые документы";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox10.Location = new System.Drawing.Point(23, 384);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(344, 26);
            this.pictureBox10.TabIndex = 96;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox11.Location = new System.Drawing.Point(23, 384);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(344, 64);
            this.pictureBox11.TabIndex = 98;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.Location = new System.Drawing.Point(263, 346);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(49, 15);
            this.label20.TabIndex = 93;
            this.label20.Text = "Номер:";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.Location = new System.Drawing.Point(263, 320);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(51, 15);
            this.label19.TabIndex = 92;
            this.label19.Text = "Серия*:";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.Location = new System.Drawing.Point(263, 294);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 15);
            this.label17.TabIndex = 91;
            this.label17.Text = "Дата рождения:";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.Location = new System.Drawing.Point(263, 243);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 15);
            this.label16.TabIndex = 90;
            this.label16.Text = "Организация:";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.Location = new System.Drawing.Point(23, 345);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(46, 15);
            this.label15.TabIndex = 89;
            this.label15.Text = "E-mail:";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.Location = new System.Drawing.Point(263, 269);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 15);
            this.label14.TabIndex = 88;
            this.label14.Text = "Примечание:";
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.Location = new System.Drawing.Point(23, 319);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 15);
            this.label13.TabIndex = 87;
            this.label13.Text = "Телефон:";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(23, 292);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 15);
            this.label12.TabIndex = 86;
            this.label12.Text = "Отчество*:";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // nomer
            // 
            this.nomer.BackColor = System.Drawing.SystemColors.ControlLight;
            this.nomer.Location = new System.Drawing.Point(364, 348);
            this.nomer.Name = "nomer";
            this.nomer.Size = new System.Drawing.Size(154, 20);
            this.nomer.TabIndex = 85;
            this.nomer.TextChanged += new System.EventHandler(this.nomer_TextChanged);
            // 
            // seriya
            // 
            this.seriya.BackColor = System.Drawing.SystemColors.ControlLight;
            this.seriya.Location = new System.Drawing.Point(364, 322);
            this.seriya.Name = "seriya";
            this.seriya.Size = new System.Drawing.Size(154, 20);
            this.seriya.TabIndex = 84;
            this.seriya.TextChanged += new System.EventHandler(this.seriya_TextChanged);
            // 
            // Data_rozhdeniya
            // 
            this.Data_rozhdeniya.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Data_rozhdeniya.Location = new System.Drawing.Point(364, 295);
            this.Data_rozhdeniya.Name = "Data_rozhdeniya";
            this.Data_rozhdeniya.Size = new System.Drawing.Size(154, 20);
            this.Data_rozhdeniya.TabIndex = 83;
            this.Data_rozhdeniya.TextChanged += new System.EventHandler(this.Data_rozhdeniya_TextChanged);
            // 
            // Primechanie
            // 
            this.Primechanie.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Primechanie.Location = new System.Drawing.Point(364, 269);
            this.Primechanie.Name = "Primechanie";
            this.Primechanie.Size = new System.Drawing.Size(154, 20);
            this.Primechanie.TabIndex = 82;
            this.Primechanie.TextChanged += new System.EventHandler(this.Primechanie_TextChanged);
            // 
            // organization
            // 
            this.organization.BackColor = System.Drawing.SystemColors.ControlLight;
            this.organization.Location = new System.Drawing.Point(364, 243);
            this.organization.Name = "organization";
            this.organization.Size = new System.Drawing.Size(154, 20);
            this.organization.TabIndex = 81;
            this.organization.TextChanged += new System.EventHandler(this.organization_TextChanged);
            // 
            // Email
            // 
            this.Email.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Email.Location = new System.Drawing.Point(99, 344);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(154, 20);
            this.Email.TabIndex = 80;
            this.Email.TextChanged += new System.EventHandler(this.Email_TextChanged);
            // 
            // Telefon
            // 
            this.Telefon.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Telefon.Location = new System.Drawing.Point(99, 318);
            this.Telefon.Name = "Telefon";
            this.Telefon.Size = new System.Drawing.Size(154, 20);
            this.Telefon.TabIndex = 79;
            this.Telefon.TextChanged += new System.EventHandler(this.Telefon_TextChanged);
            // 
            // Otchestvo
            // 
            this.Otchestvo.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Otchestvo.Location = new System.Drawing.Point(99, 292);
            this.Otchestvo.Name = "Otchestvo";
            this.Otchestvo.Size = new System.Drawing.Size(154, 20);
            this.Otchestvo.TabIndex = 78;
            this.Otchestvo.TextChanged += new System.EventHandler(this.Otchestvo_TextChanged);
            // 
            // Imya
            // 
            this.Imya.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Imya.Location = new System.Drawing.Point(99, 266);
            this.Imya.Name = "Imya";
            this.Imya.Size = new System.Drawing.Size(154, 20);
            this.Imya.TabIndex = 77;
            this.Imya.TextChanged += new System.EventHandler(this.Imya_TextChanged);
            // 
            // Familiya
            // 
            this.Familiya.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Familiya.Location = new System.Drawing.Point(99, 240);
            this.Familiya.Name = "Familiya";
            this.Familiya.Size = new System.Drawing.Size(154, 20);
            this.Familiya.TabIndex = 76;
            this.Familiya.TextChanged += new System.EventHandler(this.Familiya_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label7.Location = new System.Drawing.Point(23, 268);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 75;
            this.label7.Text = "Имя*:";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.Location = new System.Drawing.Point(23, 241);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(70, 15);
            this.label8.TabIndex = 74;
            this.label8.Text = "Фамилия*:";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(190, 195);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(207, 16);
            this.label11.TabIndex = 72;
            this.label11.Text = "Информация о посетителе";
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox7.Location = new System.Drawing.Point(15, 185);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(503, 39);
            this.pictureBox7.TabIndex = 71;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox8.Location = new System.Drawing.Point(15, 214);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(503, 164);
            this.pictureBox8.TabIndex = 73;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(726, 118);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(26, 24);
            this.pictureBox5.TabIndex = 70;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // FIO
            // 
            this.FIO.BackColor = System.Drawing.SystemColors.ControlLight;
            this.FIO.Location = new System.Drawing.Point(281, 122);
            this.FIO.Name = "FIO";
            this.FIO.Size = new System.Drawing.Size(419, 20);
            this.FIO.TabIndex = 69;
            this.FIO.TextChanged += new System.EventHandler(this.FIO_TextChanged);
            // 
            // podrazdelenie
            // 
            this.podrazdelenie.BackColor = System.Drawing.SystemColors.ControlLight;
            this.podrazdelenie.Location = new System.Drawing.Point(281, 66);
            this.podrazdelenie.Name = "podrazdelenie";
            this.podrazdelenie.Size = new System.Drawing.Size(462, 20);
            this.podrazdelenie.TabIndex = 68;
            this.podrazdelenie.TextChanged += new System.EventHandler(this.podrazdelenie_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label6.Location = new System.Drawing.Point(299, 94);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 67;
            this.label6.Text = "ФИО*:";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(299, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 15);
            this.label9.TabIndex = 66;
            this.label9.Text = "Поздразделение*:";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(434, 12);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(177, 16);
            this.label10.TabIndex = 64;
            this.label10.Text = "Принимающая сторона";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox3.Location = new System.Drawing.Point(259, 2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(529, 39);
            this.pictureBox3.TabIndex = 63;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox4.Location = new System.Drawing.Point(259, 31);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(529, 148);
            this.pictureBox4.TabIndex = 65;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // target_visit
            // 
            this.target_visit.BackColor = System.Drawing.SystemColors.ControlLight;
            this.target_visit.Location = new System.Drawing.Point(43, 148);
            this.target_visit.Name = "target_visit";
            this.target_visit.Size = new System.Drawing.Size(148, 20);
            this.target_visit.TabIndex = 62;
            this.target_visit.TextChanged += new System.EventHandler(this.target_visit_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label5.Location = new System.Drawing.Point(66, 122);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(96, 13);
            this.label5.TabIndex = 61;
            this.label5.Text = "Цель посещения:";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarMonthBackground = System.Drawing.SystemColors.ControlLight;
            this.dateTimePicker2.Location = new System.Drawing.Point(43, 95);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(117, 20);
            this.dateTimePicker2.TabIndex = 60;
            this.dateTimePicker2.ValueChanged += new System.EventHandler(this.dateTimePicker2_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(20, 94);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 13);
            this.label4.TabIndex = 59;
            this.label4.Text = "по";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarMonthBackground = System.Drawing.SystemColors.ControlLight;
            this.dateTimePicker1.Location = new System.Drawing.Point(43, 69);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(117, 20);
            this.dateTimePicker1.TabIndex = 58;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label3.Location = new System.Drawing.Point(19, 69);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(17, 13);
            this.label3.TabIndex = 57;
            this.label3.Text = "с*";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(52, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 15);
            this.label2.TabIndex = 56;
            this.label2.Text = "Срок действия заявки:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(20, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 16);
            this.label1.TabIndex = 54;
            this.label1.Text = "Информация для пропуска";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.pictureBox1.Location = new System.Drawing.Point(12, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(215, 39);
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pictureBox2.Location = new System.Drawing.Point(15, 31);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(212, 148);
            this.pictureBox2.TabIndex = 55;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // Spisok_posetitelei
            // 
            this.Spisok_posetitelei.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.Spisok_posetitelei.Location = new System.Drawing.Point(526, 185);
            this.Spisok_posetitelei.Name = "Spisok_posetitelei";
            this.Spisok_posetitelei.Size = new System.Drawing.Size(279, 39);
            this.Spisok_posetitelei.TabIndex = 102;
            this.Spisok_posetitelei.TabStop = false;
            this.Spisok_posetitelei.Click += new System.EventHandler(this.Spisok_posetitelei_Click);
            // 
            // spisok
            // 
            this.spisok.AutoSize = true;
            this.spisok.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.spisok.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.spisok.ForeColor = System.Drawing.Color.Black;
            this.spisok.Location = new System.Drawing.Point(582, 195);
            this.spisok.Name = "spisok";
            this.spisok.Size = new System.Drawing.Size(161, 16);
            this.spisok.TabIndex = 103;
            this.spisok.Text = "Список посетителей";
            this.spisok.Click += new System.EventHandler(this.spisok_Click);
            // 
            // table
            // 
            this.table.BackgroundColor = System.Drawing.SystemColors.Control;
            this.table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.table.Location = new System.Drawing.Point(531, 228);
            this.table.Name = "table";
            this.table.Size = new System.Drawing.Size(274, 150);
            this.table.TabIndex = 104;
            this.table.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.table_CellContentClick);
            // 
            // Zapis_na_group_meropriyatie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.table);
            this.Controls.Add(this.spisok);
            this.Controls.Add(this.Spisok_posetitelei);
            this.Controls.Add(this.oformit_zayavky);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.prikrepit_file);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.nomer);
            this.Controls.Add(this.seriya);
            this.Controls.Add(this.Data_rozhdeniya);
            this.Controls.Add(this.Primechanie);
            this.Controls.Add(this.organization);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Telefon);
            this.Controls.Add(this.Otchestvo);
            this.Controls.Add(this.Imya);
            this.Controls.Add(this.Familiya);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.FIO);
            this.Controls.Add(this.podrazdelenie);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.target_visit);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateTimePicker2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Zapis_na_group_meropriyatie";
            this.Text = "Групоовая форма записи на посещение мероприятия";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Spisok_posetitelei)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.table)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button oformit_zayavky;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Button prikrepit_file;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox nomer;
        private System.Windows.Forms.TextBox seriya;
        private System.Windows.Forms.TextBox Data_rozhdeniya;
        private System.Windows.Forms.TextBox Primechanie;
        private System.Windows.Forms.TextBox organization;
        private System.Windows.Forms.TextBox Email;
        private System.Windows.Forms.TextBox Telefon;
        private System.Windows.Forms.TextBox Otchestvo;
        private System.Windows.Forms.TextBox Imya;
        private System.Windows.Forms.TextBox Familiya;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox FIO;
        private System.Windows.Forms.TextBox podrazdelenie;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.TextBox target_visit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox Spisok_posetitelei;
        private System.Windows.Forms.Label spisok;
        private System.Windows.Forms.DataGridView table;
    }
}