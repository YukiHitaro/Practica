﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Data.SqlClient;
using System.Security.Cryptography;
namespace sessia1
{
    /// <summary>
    /// Interaction logic for RegistrationWindow.xaml
    /// </summary>
    public partial class RegistrationWindow : Window
    {
        public RegistrationWindow()
        {
            InitializeComponent();
        }

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            RegisterUser();
        }

        private void RegisterUser()
        {
            string connectionString = @"Data Source=KAB17-06\SQLEXPRESS;Initial Catalog=Guardian-pro;Integrated Security=True";
            string query = @"
    INSERT INTO Авторизация(ID, Email, Пароль, Соль)
    VALUES (@ID, @Email, @Password, @Salt);";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string salt = GenerateSalt();
                string hashedPassword = HashPassword(txtRegistrationPassword.Password, salt);

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ID", GetNextUserID()); // Присваивание ID от 1 до 40
                command.Parameters.AddWithValue("@Email", txtRegistrationEmail.Text);
                command.Parameters.AddWithValue("@Password", hashedPassword);
                command.Parameters.AddWithValue("@Salt", salt);
                connection.Open();
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Registration successful!", "Success");
                }
                else
                {
                    MessageBox.Show("Registration failed! Please try again.", "Error");
                }
            }
        }

        private string GenerateSalt()
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                var salt = new byte[8];
                rng.GetBytes(salt);
                return Convert.ToBase64String(salt);
            }
        }

        private string HashPassword(string password, string salt)
        {
            using (var hash = new SHA256Managed())
            {
                var hashedData = hash.ComputeHash(Encoding.UTF8.GetBytes(password + salt));
                return Convert.ToBase64String(hashedData);
            }
        }

        private bool VerifyPassword(string password, string hashedPassword, string salt)
        {
            string newHashedPassword = HashPassword(password, salt);
            return newHashedPassword == hashedPassword;
        }

       private void LoginUser()
{
    string connectionString = @"Data Source=KAB17-06\SQLEXPRESS;Initial Catalog=Guardian-pro;Integrated Security=True";
    string query = @"
    SELECT Пароль, Соль FROM Авторизация WHERE Email = @Email;";

    using (SqlConnection connection = new SqlConnection(connectionString))
    {
        SqlCommand command = new SqlCommand(query, connection);
        command.Parameters.AddWithValue("@Email", txtRegistrationEmail.Text);
        connection.Open();
        SqlDataReader reader = command.ExecuteReader();

        if (reader.Read())
        {
            string hashedPassword = reader["Пароль"].ToString();
            string salt = reader["Соль"].ToString();

            if (VerifyPassword(txtRegistrationPassword.Password, hashedPassword, salt))
            {
                MessageBox.Show("Login successful!", "Success");
            }
            else
            {
                MessageBox.Show("Invalid password. Please try again.", "Error");
            }
        }
        else
        {
            MessageBox.Show("Email not found. Please try again.", "Error");
        }

        connection.Close();
    }
}

        private int GetNextUserID()
        {

            Random rnd = new Random();
            return rnd.Next(1, 200);
        }
            private string GetUserId(string email)
        {
            string connectionString = @"Data Source=KAB17-06\SQLEXPRESS;Initial Catalog=Guardian-pro;Integrated Security=True";
            string query = "SELECT ID FROM Авторизация WHERE Email = @Email";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Email", email);

                try
                {
                    connection.Open();
                    string userId = command.ExecuteScalar() as string;
                    connection.Close();
                    return userId;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Ошибка");
                    return null;
                }
            }
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}