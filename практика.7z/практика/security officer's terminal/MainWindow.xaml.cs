﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace security_officer_s_terminal
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Request> Requests;
        public ListCollectionView filteredRequests { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            Requests = new List<Request>();
            Requests.Add(new Request { Id = 1, VisitorName = "Иван Иванов", DepartmentName = "IT", TypeName = "Индивидуальный", ArrivalTime = DateTime.Now, DepartureTime = DateTime.Now.AddHours(2) });
            Requests.Add(new Request { Id = 2, VisitorName = "Мария Петрова", DepartmentName = "HR", TypeName = "Групповой", ArrivalTime = DateTime.Now, DepartureTime = DateTime.Now.AddHours(3) });
            filteredRequests = new ListCollectionView(Requests);
            DataContext = this;
            TypeComboBox.ItemsSource = new[] { "Индивидуальный", "Групповой" };
            DepartmentComboBox.ItemsSource = new[] { "IT", "HR" };
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (CodeTextBox.Text == "1234")
            {
                LoginButton.IsEnabled = false;
            }
            else
            {
                MessageBox.Show("Неверный код");
            }
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            // Фильтруем данные по дате, типу и подразделениям
            filteredRequests.Filter = r =>
            {
                var request = r as Request;
                if (request == null) return false;

                if (TypeComboBox.SelectedIndex != -1 && TypeComboBox.SelectedItem.ToString() != request.TypeName) return false;
                if (DepartmentComboBox.SelectedIndex != -1 && DepartmentComboBox.SelectedItem.ToString() != request.DepartmentName) return false;

                return true;
            };
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            // Поиск по фамилии, имени, отчеству или номеру паспорта
            var searchText = SearchTextBox.Text;
            filteredRequests.Filter = r => ((Request)r).VisitorName.Contains(searchText, StringComparison.OrdinalIgnoreCase);
        }
    }

    public class Request
    {
        public int Id { get; set; }
        public string VisitorName { get; set; }
        public string DepartmentName { get; set; }
        public string TypeName { get; set; }
        public DateTime ArrivalTime { get; set; }
        public DateTime DepartureTime { get; set; }
    }
}
