﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp
{
    public partial class WpfApp : Window
    {
        public WpfApp()
        {
            InitializeComponent();
        }


        private void GenerateDailyReportButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateReport(ReportType.Daily);
        }

        private void GenerateMonthlyReportButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateReport(ReportType.Monthly);
        }

        private void GenerateYearlyReportButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateReport(ReportType.Yearly);
        }

        private void GenerateCurrentVisitorsReportButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateCurrentVisitorsReport();
        }

        private void GenerateHourlyReportButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateHourlyReport();
        }

        private void GenerateReport(ReportType reportType)
        {

        }

        private void GenerateCurrentVisitorsReport()
        {
        }

        private void GenerateHourlyReport()
        {
            string reportsFolder = @"D:\Архив\Воробьев\практика\Отчеты ТБ";
            if (!Directory.Exists(reportsFolder))
            {
                Directory.CreateDirectory(reportsFolder);
            }

            string fileName = $"HourlyReport_{DateTime.Now:yyyy-MM-dd_HH-mm-ss}.xlsx";
            string filePath = Path.Combine(reportsFolder, fileName);
        }
    }

    public enum ReportType
    {
        Daily,
        Monthly,
        Yearly
    }
}